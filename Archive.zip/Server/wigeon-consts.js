// Server Constants
var WigeonConsts = function() {
	var self = this; 
	self.SALTA = "Superior";
	self.SALTB = "Boisterious";

	// yelp
	self.YelpConsumerKey = 'lKkcg8K312U3GcPuF8d_Eg';
	self.YelpConsumerSecret = 'aAYgRl9NlmCZeVAhMMzNaHR380U';
	self.YelpToken = 'gHBzFC4tETChx6cIN8Te4-Spchzlhcpn';
	self.YelpTokenSecret = 'CwneNMN8-3SfuVhsqv6wU48THfI';
}

module.exports.WigeonConsts = WigeonConsts;

