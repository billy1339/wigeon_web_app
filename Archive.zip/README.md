TO DO: 

* When a user goes to any page and is not logged in redirect to home/login
* When a user is logged in and goes to home page redirect to nest
* snag the image not found logic from work and inplement it here...
* remove suggestinos that are deleted from the list that appear in the nest
* nav bar active tabs
* encrypt cookie and salts
* paginate nest 
* encrypt yelp api access token
* possible hash library https://www.npmjs.com/package/crypto-js



NEW
* change sign-in links to log in
* nav bar make nav bar right when you sign in/sign out.