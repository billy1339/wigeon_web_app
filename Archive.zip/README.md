TO DO: 

* When a user is logged in and goes to home page redirect to nest
* snag the image not found logic from work and inplement it here...
* remove suggestinos that are deleted from the list that appear in the nest
* loading indicator for videos
* move sign in w/ email to server
* move sign up to server
* default profile image
* fallback images

http://staging-wigeon-webapp.us-east-1.elasticbeanstalk.com/
